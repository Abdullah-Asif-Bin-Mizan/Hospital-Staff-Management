//Proxy Design Pattern
public interface Communication {
        void createCommunication(String sender, String receiver);

}

