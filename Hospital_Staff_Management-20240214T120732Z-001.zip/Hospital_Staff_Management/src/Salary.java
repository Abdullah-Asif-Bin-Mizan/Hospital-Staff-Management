//Facade Design Pattern
import java.util.*;
public interface Salary {

    public static void calculateSalary(){

    }

}

