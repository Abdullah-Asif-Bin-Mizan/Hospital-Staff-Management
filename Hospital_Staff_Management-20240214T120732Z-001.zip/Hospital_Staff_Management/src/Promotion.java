//Decorator Design patter  STEP:1

//import java.util.*; for user input
import java.util.*;

public interface Promotion {
    Scanner sc = new Scanner(System.in);
    public static void calculatePromotion(){

    }
}
